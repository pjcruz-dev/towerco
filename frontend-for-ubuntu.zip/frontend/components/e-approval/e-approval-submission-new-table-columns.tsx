"use client";

import { ArrowRight } from "lucide-react";
import type { ColumnDef } from "@tanstack/react-table";

import { Button } from "@/components/ui/button";
import {
  createActionsColumn,
  createTextColumn,
} from "@/components/ui/data-table-column-helpers";
import type { EApprovalFormListRow } from "@/modules/e-approval/types";

function formatCategory(category: string): string {
  const trimmed = category.trim();
  if (!trimmed) return "General";
  return trimmed.charAt(0).toUpperCase() + trimmed.slice(1);
}

export function createEApprovalSubmissionNewTableColumns(options: {
  onStart: (formId: string) => void;
}): ColumnDef<EApprovalFormListRow>[] {
  return [
    createTextColumn("name", "Form", (row) => <span className="font-medium">{row.name}</span>, {
      enableSorting: true,
      sortValue: (row) => row.name,
    }),
    createTextColumn(
      "category",
      "Category",
      (row) => <span className="text-muted-foreground">{formatCategory(row.category)}</span>,
      { enableSorting: true, sortValue: (row) => formatCategory(row.category) },
    ),
    createTextColumn(
      "description",
      "Description",
      (row) => (
        <span className="max-w-md truncate text-sm text-muted-foreground">
          {row.description?.trim() || "—"}
        </span>
      ),
    ),
    createActionsColumn("Start", (row) => (
      <Button type="button" size="sm" className="gap-1" onClick={() => options.onStart(row.original.id)}>
        Start
        <ArrowRight className="h-3.5 w-3.5" />
      </Button>
    )),
  ];
}
