"use client";

import { useMemo } from "react";

import { TenantBrandMark } from "@/components/layout/tenant-brand-mark";
import { useOrganizationLabel } from "@/hooks/use-organization-label";
import { cn } from "@/lib/utils";

type Props = {
  variant: "tenant" | "platform";
  className?: string;
};

/** Sidebar header brand — organization logo/title from branding + auth context. */
export function SidebarBrand({ variant, className }: Props) {
  const organizationLabel = useOrganizationLabel();

  const title = useMemo(() => {
    if (variant === "platform") {
      return "TowerOS";
    }
    return organizationLabel;
  }, [organizationLabel, variant]);

  const subtitle = variant === "platform" ? "Superadmin console" : "Workspace";

  return (
    <div
      className={cn(
        "flex min-w-0 items-center gap-3 group-data-[collapsible=icon]:justify-center",
        className,
      )}
    >
      <TenantBrandMark />
      <div className="flex min-w-0 flex-col overflow-hidden group-data-[collapsible=icon]:hidden">
        <span className="truncate text-base font-semibold tracking-tight text-sidebar-foreground">{title}</span>
        <span className="truncate text-xs text-sidebar-foreground/50">{subtitle}</span>
      </div>
    </div>
  );
}
