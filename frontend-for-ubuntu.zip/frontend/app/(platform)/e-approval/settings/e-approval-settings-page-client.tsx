"use client";

import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useState } from "react";

import { EApprovalPageHeader } from "@/components/e-approval/e-approval-page-header";
import { EApprovalSectionCard } from "@/components/e-approval/e-approval-section-card";
import { PermissionGate } from "@/components/layout/permission-gate";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { fetchEApprovalSettings, updateEApprovalSettings } from "@/lib/api/modules/e-approval-api";
import { getErrorMessage } from "@/lib/api/error";
import { permissions } from "@/lib/rbac/permissions";
import type { EApprovalFinanceProcurementPolicy } from "@/modules/e-approval/finance-procurement-policy";

type SettingsForm = {
  liquidation_requires_parent: boolean;
  liquidation_overspend_mode: "block" | "warn";
  liquidation_max_overspend_percent: number;
  po_overspend_mode: "block" | "warn";
  po_max_overspend_percent: number;
};

const defaultForm: SettingsForm = {
  liquidation_requires_parent: true,
  liquidation_overspend_mode: "block",
  liquidation_max_overspend_percent: 0,
  po_overspend_mode: "block",
  po_max_overspend_percent: 0,
};

function parsePolicy(data: Record<string, string | number | EApprovalFinanceProcurementPolicy | undefined>): SettingsForm {
  const nested = data.finance_procurement_policy;
  const source = typeof nested === "object" && nested !== null ? nested : data;

  return {
    liquidation_requires_parent: toBool(source.liquidation_requires_parent, true),
    liquidation_overspend_mode: source.liquidation_overspend_mode === "warn" ? "warn" : "block",
    liquidation_max_overspend_percent: toInt(source.liquidation_max_overspend_percent, 0),
    po_overspend_mode: source.po_overspend_mode === "warn" ? "warn" : "block",
    po_max_overspend_percent: toInt(source.po_max_overspend_percent, 0),
  };
}

function toBool(value: unknown, fallback: boolean): boolean {
  if (typeof value === "boolean") return value;
  if (typeof value === "string") return value === "true";
  return fallback;
}

function toInt(value: unknown, fallback: number): number {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : fallback;
}

export function EApprovalSettingsPageClient() {
  const queryClient = useQueryClient();
  const [form, setForm] = useState<SettingsForm>(defaultForm);
  const [error, setError] = useState<string | null>(null);
  const [saved, setSaved] = useState(false);

  const { data, isLoading, isError } = useQuery({
    queryKey: ["e-approval", "settings"],
    queryFn: fetchEApprovalSettings,
  });

  useEffect(() => {
    if (data) {
      setForm(parsePolicy(data));
    }
  }, [data]);

  const saveMutation = useMutation({
    mutationFn: () =>
      updateEApprovalSettings({
        liquidation_requires_parent: form.liquidation_requires_parent ? "true" : "false",
        liquidation_overspend_mode: form.liquidation_overspend_mode,
        liquidation_max_overspend_percent: form.liquidation_max_overspend_percent,
        po_overspend_mode: form.po_overspend_mode,
        po_max_overspend_percent: form.po_max_overspend_percent,
      }),
    onSuccess: async () => {
      setError(null);
      setSaved(true);
      await queryClient.invalidateQueries({ queryKey: ["e-approval", "settings"] });
      await queryClient.invalidateQueries({ queryKey: ["e-approval", "metadata"] });
    },
    onError: (mutationError) => setError(getErrorMessage(mutationError)),
  });

  return (
    <PermissionGate requiredPermissions={[permissions.eApprovalSettingsManage]}>
      <div className="space-y-6">
        <EApprovalPageHeader
          title="E-Approval settings"
          description="Tenant finance and procurement controls for cash advance and purchase workflows."
          actions={
            <Button
              size="sm"
              type="button"
              onClick={() => {
                setSaved(false);
                saveMutation.mutate();
              }}
              disabled={saveMutation.isPending || isLoading}
            >
              Save changes
            </Button>
          }
        />

        {isError ? <p className="text-sm text-destructive">Could not load settings.</p> : null}
        {error ? <p className="text-sm text-destructive">{error}</p> : null}
        {saved ? <p className="text-sm text-green-600 dark:text-green-400">Settings saved.</p> : null}
        {isLoading && !data ? <p className="text-sm text-muted-foreground">Loading settings…</p> : null}

        <EApprovalSectionCard
          title="Cash advance & liquidation"
          description="Control whether liquidation must link to an approved cash advance and how over-balance totals are handled."
        >
          <div className="space-y-5">
            <div className="flex items-center justify-between gap-4 rounded-lg border border-border px-3 py-3">
              <div>
                <Label htmlFor="liquidation_requires_parent">Require linked cash advance</Label>
                <p className="text-xs text-muted-foreground">
                  When enabled, liquidation submissions must include a parent cash advance.
                </p>
              </div>
              <Switch
                id="liquidation_requires_parent"
                checked={form.liquidation_requires_parent}
                onCheckedChange={(checked) =>
                  setForm((current) => ({ ...current, liquidation_requires_parent: checked }))
                }
              />
            </div>

            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label>Over-liquidation mode</Label>
                <Select
                  value={form.liquidation_overspend_mode}
                  onChange={(event) =>
                    setForm((current) => ({
                      ...current,
                      liquidation_overspend_mode: event.target.value as "block" | "warn",
                    }))
                  }
                >
                  <option value="block">Block above open balance</option>
                  <option value="warn">Warn and allow buffer</option>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="liquidation_max_overspend_percent">Max overspend percent</Label>
                <Select
                  id="liquidation_max_overspend_percent"
                  value={String(form.liquidation_max_overspend_percent)}
                  disabled={form.liquidation_overspend_mode !== "warn"}
                  onChange={(event) =>
                    setForm((current) => ({
                      ...current,
                      liquidation_max_overspend_percent: Number(event.target.value),
                    }))
                  }
                >
                  {Array.from({ length: 26 }, (_, index) => (
                    <option key={index} value={String(index)}>
                      {index}%
                    </option>
                  ))}
                </Select>
              </div>
            </div>
          </div>
        </EApprovalSectionCard>

        <EApprovalSectionCard
          title="Purchase requisition & PO"
          description="Control how purchase orders may exceed the remaining PR budget."
        >
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2">
              <Label>PO overspend mode</Label>
              <Select
                value={form.po_overspend_mode}
                onChange={(event) =>
                  setForm((current) => ({
                    ...current,
                    po_overspend_mode: event.target.value as "block" | "warn",
                  }))
                }
              >
                <option value="block">Block above open balance</option>
                <option value="warn">Warn and allow buffer</option>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="po_max_overspend_percent">Max overspend percent</Label>
              <Select
                id="po_max_overspend_percent"
                value={String(form.po_max_overspend_percent)}
                disabled={form.po_overspend_mode !== "warn"}
                onChange={(event) =>
                  setForm((current) => ({
                    ...current,
                    po_max_overspend_percent: Number(event.target.value),
                  }))
                }
              >
                {Array.from({ length: 26 }, (_, index) => (
                  <option key={index} value={String(index)}>
                    {index}%
                  </option>
                ))}
              </Select>
            </div>
          </div>
        </EApprovalSectionCard>
      </div>
    </PermissionGate>
  );
}
