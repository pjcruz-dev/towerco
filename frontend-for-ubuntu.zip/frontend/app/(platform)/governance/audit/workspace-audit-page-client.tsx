"use client";

import { useQuery } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { ScrollText } from "lucide-react";

import { PermissionGate } from "@/components/layout/permission-gate";
import { PaginatedListFooter } from "@/components/registry/paginated-list-footer";
import { RegistryDataTableView } from "@/components/registry/registry-data-table-view";
import { workspaceAuditTableColumns } from "@/components/registry/workspace-audit-table-columns";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { useDebouncedValue } from "@/hooks/use-debounced-value";
import { useServerTableSort } from "@/hooks/use-server-table-sort";
import { fetchWorkspaceAuditIndex } from "@/lib/api/modules/workspace-audit-api";
import { permissions } from "@/lib/rbac/permissions";

const PER_PAGE = 50;
const DEFAULT_SORT = "created_at:desc";

export function WorkspaceAuditPageClient() {
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState("");
  const [module, setModule] = useState("");
  const debouncedSearch = useDebouncedValue(search, 350, () => setPage(1));
  const { sort, sorting, onSortingChange, manualSorting } = useServerTableSort({
    defaultSort: DEFAULT_SORT,
    sortableColumnIds: ["created_at", "module", "action"],
  });

  useEffect(() => {
    setPage(1);
  }, [sort]);

  const { data, isFetching, isError } = useQuery({
    queryKey: ["workspace", "audit", page, debouncedSearch, module, sort],
    queryFn: () =>
      fetchWorkspaceAuditIndex({
        page,
        per_page: PER_PAGE,
        search: debouncedSearch.trim() || undefined,
        module: module || undefined,
        sort,
      }),
  });

  const rows = data?.data ?? [];
  const meta = data?.meta;

  return (
    <PermissionGate requiredPermissions={[permissions.workspaceAuditView]}>
      <div className="space-y-6">
        <header>
          <h1 className="text-2xl font-semibold tracking-tight text-foreground">Workspace audit trail</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Cross-module activity across E-Approval, documents, security, and workspace changes. Older module-specific
            logs are federated here when you have access.
          </p>
        </header>

        <div className="flex flex-wrap items-end gap-3 rounded-xl border border-border bg-card p-4 shadow-sm">
          <div className="min-w-[220px] flex-1 space-y-1.5">
            <label htmlFor="audit-search" className="text-xs font-medium text-muted-foreground">
              Search
            </label>
            <Input
              id="audit-search"
              value={search}
              onChange={(event) => setSearch(event.target.value)}
              placeholder="Action, user, entity, summary…"
            />
          </div>
          <div className="w-full min-w-[160px] space-y-1.5 sm:w-auto">
            <label htmlFor="audit-module" className="text-xs font-medium text-muted-foreground">
              Module
            </label>
            <Select id="audit-module" value={module} onChange={(event) => { setModule(event.target.value); setPage(1); }}>
              <option value="">All modules</option>
              <option value="e_approval">E-Approval</option>
              <option value="documents">Documents</option>
              <option value="team_access">Team &amp; access</option>
              <option value="procurement_one">Procurement</option>
            </Select>
          </div>
        </div>

        <section className="rounded-xl border border-border bg-card shadow-sm">
          <div className="flex items-center gap-2 border-b border-border px-4 py-3">
            <ScrollText className="h-4 w-4 text-muted-foreground" />
            <h2 className="text-base font-medium">Activity log</h2>
          </div>

          <RegistryDataTableView
            columns={workspaceAuditTableColumns}
            data={rows}
            getRowId={(row) => row.id}
            isLoading={isFetching && rows.length === 0}
            isEmpty={!isFetching && (isError || rows.length === 0)}
            emptyMessage={
              isError ? "Could not load audit trail." : "No audit events match your filters."
            }
            enableColumnVisibility
            columnVisibilityStorageKey="toweros.table.columns.governance.audit"
            sorting={sorting}
            onSortingChange={onSortingChange}
            manualSorting={manualSorting}
          />

          {meta ? (
            <PaginatedListFooter meta={meta} onPageChange={setPage} isPending={isFetching} />
          ) : null}
        </section>
      </div>
    </PermissionGate>
  );
}
